"""Basic database tests; run with: python -m unittest discover -s tests"""
import sqlite3
import tempfile
import unittest
from pathlib import Path


class AttendanceDatabaseTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test.db"
        self.conn = sqlite3.connect(self.db_path)
        self.conn.execute("""
            CREATE TABLE students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                roll_no TEXT NOT NULL UNIQUE
            )
        """)
        self.conn.execute("""
            CREATE TABLE attendance (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id INTEGER NOT NULL,
                attendance_date TEXT NOT NULL,
                status TEXT NOT NULL CHECK(status IN ('Present', 'Absent')),
                UNIQUE(student_id, attendance_date),
                FOREIGN KEY(student_id) REFERENCES students(id)
            )
        """)
        self.conn.commit()

    def tearDown(self):
        self.conn.close()
        self.temp_dir.cleanup()

    def test_student_can_be_added(self):
        self.conn.execute(
            "INSERT INTO students (name, roll_no) VALUES (?, ?)",
            ("Asha", "BCA001"),
        )
        self.conn.commit()
        row = self.conn.execute(
            "SELECT name, roll_no FROM students WHERE roll_no = ?",
            ("BCA001",),
        ).fetchone()
        self.assertEqual(row, ("Asha", "BCA001"))

    def test_duplicate_roll_number_is_rejected(self):
        self.conn.execute(
            "INSERT INTO students (name, roll_no) VALUES (?, ?)",
            ("Asha", "BCA001"),
        )
        with self.assertRaises(sqlite3.IntegrityError):
            self.conn.execute(
                "INSERT INTO students (name, roll_no) VALUES (?, ?)",
                ("Ravi", "BCA001"),
            )

    def test_attendance_is_unique_per_student_and_date(self):
        self.conn.execute(
            "INSERT INTO students (name, roll_no) VALUES (?, ?)",
            ("Asha", "BCA001"),
        )
        student_id = self.conn.execute(
            "SELECT id FROM students WHERE roll_no = ?", ("BCA001",)
        ).fetchone()[0]
        self.conn.execute(
            "INSERT INTO attendance (student_id, attendance_date, status) VALUES (?, ?, ?)",
            (student_id, "2026-10-21", "Present"),
        )
        with self.assertRaises(sqlite3.IntegrityError):
            self.conn.execute(
                "INSERT INTO attendance (student_id, attendance_date, status) VALUES (?, ?, ?)",
                (student_id, "2026-10-21", "Absent"),
            )


if __name__ == "__main__":
    unittest.main()
