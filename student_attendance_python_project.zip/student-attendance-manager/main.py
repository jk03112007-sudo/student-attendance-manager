"""Student Attendance Manager - a beginner-friendly Python + SQLite project."""

import sqlite3
from datetime import date, datetime
from pathlib import Path

DB_PATH = Path(__file__).with_name("attendance.db")


def connect():
    """Open a database connection and create tables if needed."""
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            roll_no TEXT NOT NULL UNIQUE
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            attendance_date TEXT NOT NULL,
            status TEXT NOT NULL CHECK(status IN ('Present', 'Absent')),
            UNIQUE(student_id, attendance_date),
            FOREIGN KEY(student_id) REFERENCES students(id)
        )
    """)
    conn.commit()
    return conn


def add_student(conn):
    name = input("Student name: ").strip()
    roll_no = input("Roll number: ").strip()
    if not name or not roll_no:
        print("Name and roll number cannot be empty.")
        return
    try:
        conn.execute("INSERT INTO students (name, roll_no) VALUES (?, ?)", (name, roll_no))
        conn.commit()
        print(f"Added {name} (Roll No. {roll_no}).")
    except sqlite3.IntegrityError:
        print("That roll number already exists.")


def list_students(conn):
    students = conn.execute(
        "SELECT id, name, roll_no FROM students ORDER BY roll_no"
    ).fetchall()
    if not students:
        print("No students added yet.")
        return []
    print("\nID   Roll No.       Name")
    print("-" * 42)
    for student_id, name, roll_no in students:
        print(f"{student_id:<4} {roll_no:<14} {name}")
    return students


def mark_attendance(conn):
    students = list_students(conn)
    if not students:
        return
    day = input(f"Date (YYYY-MM-DD, default {date.today()}): ").strip() or str(date.today())
    try:
        datetime.strptime(day, "%Y-%m-%d")
    except ValueError:
        print("Invalid date. Please use YYYY-MM-DD.")
        return

    for student_id, name, roll_no in students:
        while True:
            answer = input(f"{name} ({roll_no}) — Present or Absent? [P/A]: ").strip().lower()
            if answer in ("p", "present"):
                status = "Present"
                break
            if answer in ("a", "absent"):
                status = "Absent"
                break
            print("Enter P for Present or A for Absent.")
        conn.execute("""
            INSERT INTO attendance (student_id, attendance_date, status)
            VALUES (?, ?, ?)
            ON CONFLICT(student_id, attendance_date)
            DO UPDATE SET status = excluded.status
        """, (student_id, day, status))
    conn.commit()
    print(f"Attendance saved for {day}.")


def show_report(conn):
    students = conn.execute("""
        SELECT s.id, s.name, s.roll_no,
               COUNT(a.id) AS total,
               SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS present
        FROM students s
        LEFT JOIN attendance a ON a.student_id = s.id
        GROUP BY s.id
        ORDER BY s.roll_no
    """).fetchall()
    if not students:
        print("No students found.")
        return
    print("\nATTENDANCE REPORT")
    print("-" * 76)
    print(f"{'Roll No.':<14}{'Name':<24}{'Present':>9}{'Total':>8}{'Rate':>10}")
    print("-" * 76)
    for _, name, roll_no, total, present in students:
        total = total or 0
        present = present or 0
        rate = (present / total * 100) if total else 0
        print(f"{roll_no:<14}{name[:22]:<24}{present:>9}{total:>8}{rate:>9.1f}%")
    print("-" * 76)


def show_daily_report(conn):
    day = input(f"Date (YYYY-MM-DD, default {date.today()}): ").strip() or str(date.today())
    try:
        datetime.strptime(day, "%Y-%m-%d")
    except ValueError:
        print("Invalid date. Please use YYYY-MM-DD.")
        return
    rows = conn.execute("""
        SELECT s.roll_no, s.name, a.status
        FROM students s
        LEFT JOIN attendance a
          ON a.student_id = s.id AND a.attendance_date = ?
        ORDER BY s.roll_no
    """, (day,)).fetchall()
    print(f"\nDAILY ATTENDANCE — {day}")
    print("-" * 48)
    for roll_no, name, status in rows:
        print(f"{roll_no:<14} {name:<24} {status or 'Not marked'}")
    if not rows:
        print("No students found.")


def main():
    conn = connect()
    print("=" * 38)
    print("     STUDENT ATTENDANCE MANAGER")
    print("=" * 38)
    try:
        while True:
            print("""
1. Add student
2. View students
3. Mark attendance
4. Overall attendance report
5. Daily attendance report
0. Exit
""")
            choice = input("Choose an option: ").strip()
            if choice == "1":
                add_student(conn)
            elif choice == "2":
                list_students(conn)
            elif choice == "3":
                mark_attendance(conn)
            elif choice == "4":
                show_report(conn)
            elif choice == "5":
                show_daily_report(conn)
            elif choice == "0":
                print("Goodbye!")
                break
            else:
                print("Invalid option. Choose 0–5.")
    except (KeyboardInterrupt, EOFError):
        print("\nExiting...")
    finally:
        conn.close()


if __name__ == "__main__":
    main()
