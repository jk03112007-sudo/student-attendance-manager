# Student Attendance Manager

A beginner-friendly **Python + SQLite** command-line project to manage students and track daily attendance. It is suitable for a BCA portfolio and can be extended into a GUI or face-recognition system later.

## Features

- Add students with a unique roll number
- View the student list
- Mark students Present or Absent
- Save attendance by date
- Update a student's attendance if it is marked again for the same date
- View daily attendance, including students whose attendance has not been marked
- Calculate each student's overall attendance percentage
- Store data locally in SQLite (no server required)

## Requirements

- Python 3.9 or newer
- No third-party packages required

## Run the project

1. Download or clone this repository.
2. Open a terminal in the project folder.
3. Run:

   ```bash
   python main.py
   ```

   On some systems, use `python3 main.py`.

The database file `attendance.db` is created automatically when you first run the program.

## How to use

1. Select **1** to add students.
2. Select **2** to check the student list.
3. Select **3** to mark attendance. Enter `P` for Present or `A` for Absent.
4. Select **4** for each student's overall attendance percentage.
5. Select **5** to view attendance for a particular date.
6. Select **0** to exit.

Dates must use `YYYY-MM-DD`, for example `2026-10-21`.

## Project structure

```text
student-attendance-manager/
├── main.py
├── README.md
├── requirements.txt
├── .gitignore
└── tests/
    └── test_database.py
```

## Database design

- `students`: student name and unique roll number
- `attendance`: student, date, and status
- A student can have only one attendance record per date.

## Future improvements

- Add a graphical interface using Tkinter
- Export reports to CSV or Excel
- Add search and edit-student features
- Add login and roles for teachers/admins
- Build an optional face-recognition module with clear consent and privacy safeguards

## Learning outcomes

This project demonstrates Python functions, input validation, exception handling, SQL queries, SQLite database operations, and basic reporting.

## License

This project is released under the MIT License. See `LICENSE`.
